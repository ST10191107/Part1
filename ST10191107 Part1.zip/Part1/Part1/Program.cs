﻿using System;

namespace RecipeApp
{
    class Recipe
    {
        
        public string Name { get; set; }
        public int NumIngredients { get; set; }
        public Ingredient[] Ingredients { get; set; }
        public int NumSteps { get; set; }
        public string[] Steps { get; set; }

        // Constructor
        public Recipe(string name, int numIngredients, int numSteps)
        {
            Name = name;
            NumIngredients = numIngredients;
            Ingredients = new Ingredient[numIngredients];
            NumSteps = numSteps;
            Steps = new string[numSteps];
        }

        //  scale ingredients
        public void ScaleIngredients(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        //  reset ingredient quantities
        public void ResetQuantities()
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity = ingredient.InitialQuantity;
            }
        }

        // Method to clear all data
        public void Clear()
        {
            Name = "";
            NumIngredients = 0;
            Ingredients = new Ingredient[0];
            NumSteps = 0;
            Steps = new string[0];
        }

        // display the recipe
        public void Display()
        {
            Console.WriteLine($"Recipe: {Name}");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Name}: {ingredient.Quantity} {ingredient.Unit}");
            }
            Console.WriteLine("Steps:");
            for (int i = 0; i < Steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i]}");
            }
        }
    }

    class Ingredient
    {
       
        public string Name { get; set; }
        public double Quantity { get; set; }
        public double InitialQuantity { get; set; }
        public string Unit { get; set; }

        // Constructor
        public Ingredient(string name, double quantity, string unit)
        {
            Name = name;
            Quantity = quantity;
            InitialQuantity = quantity;
            Unit = unit;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Recipe App!");

            // recipe details
            Console.Write("Enter recipe name: ");
            string name = Console.ReadLine();

            Console.Write("Enter number of ingredients: ");
            int numIngredients = int.Parse(Console.ReadLine());
            Ingredient[] ingredients = new Ingredient[numIngredients];
            for (int i = 0; i < numIngredients; i++)
            {
                Console.Write($"Enter ingredient {i + 1} name: ");
                string ingredientName = Console.ReadLine();
                Console.Write($"Enter quantity of {ingredientName}: ");
                double quantity = double.Parse(Console.ReadLine());
                Console.Write($"Enter unit of measurement for {ingredientName}: ");
                string unit = Console.ReadLine();
                ingredients[i] = new Ingredient(ingredientName, quantity, unit);
            }

            Console.Write("Enter number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());
            string[] steps = new string[numSteps];
            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Enter step {i + 1}: ");
                steps[i] = Console.ReadLine();
            }

            // Create recipe 
            Recipe recipe = new Recipe(name, numIngredients, numSteps);
            recipe.Ingredients = ingredients;
            recipe.Steps = steps;

            // Display recipe
            recipe.Display();

            // Scaling the recipe
            Console.WriteLine("Do you want to scale the recipe? Enter factor (0.5, 2, or 3): ");
            double factor = double.Parse(Console.ReadLine());
            recipe.ScaleIngredients(factor);
            Console.WriteLine("Scaled recipe:");
            recipe.Display();

            // Reset quantities
            Console.WriteLine("Do you want to reset Recipe to original quantities? Enter yes/no: ");
            string answer = Console.ReadLine();
            if (answer.ToLower() == "yes")
            {
                recipe.ResetQuantities();
                Console.WriteLine("Recipe with original quantities:");
                recipe.Display();
            }

            // Clear recipe
            Console.WriteLine("Do you want to Clear Recipe? Enter yes/no: ");
            string clear = Console.ReadLine();
            if (clear.ToLower() == "yes")
            {
                

                recipe.Clear();
                Console.WriteLine("Recipe data cleared.");
            }
            else
            {
                recipe.Display();
            }
        }
    }
}